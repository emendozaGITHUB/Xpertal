﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MIM_BLUE_MA
{
    public class BLUE_MA
    {
        private const string LoginEndpointUrl = "https://www.yzatesting.mx/Conversion/BlueAPIntegrationMinCC/api/login";
        private const string UserEndpointUrl = "https://www.yzatesting.mx/Conversion/BlueAPIntegrationMinCC/api/userregistration";
        private const string FindUserEndpointUrl = "https://www.yzatesting.mx/Conversion/BlueAPIntegrationMinCC/api/FindUser/";

        private const string LoginId = "MINFYBEUser";
        private const string Password = "2Eb=9$tQ73i9";

        private readonly HttpClient _httpClient;
        private string _token;

        public BLUE_MA()
        {
            _httpClient = new HttpClient();
        }

        private async Task EnsureTokenAsync()
        {
            if (!string.IsNullOrEmpty(_token))
                return;

            var loginData = new { loginId = LoginId, password = Password };
            var jsonData = JsonSerializer.Serialize(loginData);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            try
            {
                Logger.LogInfo("Obteniendo token...");
                var response = await _httpClient.PostAsync(LoginEndpointUrl, content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();

                var tokenResponse = JsonSerializer.Deserialize<TokenResponse>(responseContent);
                _token = tokenResponse?.token ?? throw new InvalidOperationException("El token no se encontró en la respuesta.");
                Logger.LogInfo("Token obtenido correctamente.");
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error al obtener el token: {ex.Message}");
                throw;
            }
        }

        public async Task<string> SaveUserAsync(NewUserRequest userRequest)
        {
            await EnsureTokenAsync();

            var jsonData = JsonSerializer.Serialize(userRequest);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _token);

            try
            {
                Logger.LogInfo("Enviando solicitud para guardar usuario...");
                var response = await _httpClient.PostAsync(UserEndpointUrl, content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                Logger.LogInfo("Usuario guardado exitosamente.: " + JsonSerializer.Serialize(userRequest));
                return responseContent;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error al guardar el usuario: {ex.Message}");
                throw;
            }
        }


        public async Task<string> UpdateUserAsync(NewUserRequest userRequest)
        {
            await EnsureTokenAsync();

            var jsonData = JsonSerializer.Serialize(userRequest);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _token);

            try
            {
                Logger.LogInfo("Enviando solicitud para actualizar usuario...");
                var response = await _httpClient.PostAsync(UserEndpointUrl, content);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                Logger.LogInfo("Usuario guardado exitosamente.: " + JsonSerializer.Serialize(userRequest));
                return responseContent;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error al guardar el usuario: {ex.Message}");
                throw;
            }
        }

        public async Task<UserSearchResponse> FindUserAsync(string userId)
        {
            await EnsureTokenAsync(); 

            var url = $"{FindUserEndpointUrl}{userId}";
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _token);

            try
            {
                Logger.LogInfo($"Buscando usuario con ID: {userId}...");
                var response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                var userResponse = JsonSerializer.Deserialize<UserSearchResponse>(responseContent);
                Logger.LogInfo("Usuario encontrado exitosamente: " + JsonSerializer.Serialize(userResponse));

                if (userResponse?.isSuccess != true)
                {
                    throw new InvalidOperationException($"Error en la respuesta: {userResponse?.message}");
                }

                return userResponse;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error al buscar el usuario con ID {userId}: {ex.Message}");
                throw;
            }
        }

        private class TokenResponse
        {
            public bool isSuccess { get; set; }
            public string token { get; set; }
        }

        public class NewUserRequest
        {
            public int wsuserTypeId { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string loginId { get; set; }
            public string email { get; set; }
            public string employeeID { get; set; }
            public bool active { get; set; }
            public bool isPasswordTemp { get; set; }
            public string passwordTemp { get; set; }
            public DateTime addedDate { get; set; }
            public DateTime lastUpdate { get; set; }
        }

        public class UserSearchResponse
        {
            public bool isSuccess { get; set; }
            public string message { get; set; }
            public UserData data { get; set; }
        }

        public class UserData
        {
            public int wsuserTypeId { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string loginId { get; set; }
            public string email { get; set; }
            public string employeeID { get; set; }
            public bool active { get; set; }
            public bool isPasswordTemp { get; set; }
            public string passwordTemp { get; set; }
            public DateTime addedDate { get; set; }
            public DateTime lastUpdate { get; set; }
        }
    }
}
