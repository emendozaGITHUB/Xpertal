﻿using System;
using System.IO;

public static class Logger
{
    private const string LogFilePath = "LOG_MIM_BLUE_MA.txt"; 

    public static void LogInfo(string message)
    {
        WriteToFile($"INFO: {message}");
    }

    public static void LogError(string message)
    {
        WriteToFile($"ERROR: {message}");
    }

    private static void WriteToFile(string message)
    {
        try
        {

            File.AppendAllText(LogFilePath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}{Environment.NewLine}");
        }
        catch (Exception ex)
        {

            Console.WriteLine($"Error al escribir en el log: {ex.Message}");
        }
    }
}